<?php 
session_start();

// Check if user is logged in and is a student
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'student') {
    header("Location: LOGIN1.html"); // Redirect to login page if unauthorized
    exit();
}
?>

