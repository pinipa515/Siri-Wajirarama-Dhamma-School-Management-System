<?php
session_start();
include 'db_connect.php';


$teacher_id = $_SESSION['teacher_id'];

// Fetch feedback for this teacher
$sql = "SELECT message, submitted_at FROM feedbacks WHERE teacher_id = ? ORDER BY submitted_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Anonymous Feedback from Students</h2>
    
    <table border="1">
        <tr>
            <th>Feedback</th>
            <th>Submitted At</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['message']); ?></td>
                    <td><?php echo $row['submitted_at']; ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="2">No feedback available.</td></tr>
        <?php endif; ?>
    </table>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
