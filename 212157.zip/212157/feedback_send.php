<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $class = $_POST['class'];
    $feedback = $_POST['feedback'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "school_db"); // Update with your database credentials

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch teacher emails based on the class
    $sql = "SELECT personal_email, official_email FROM teachers WHERE class_assigned = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $class);
    $stmt->execute();
    $stmt->bind_result($personalEmail, $officialEmail);
    $stmt->fetch();
    $stmt->close();

    $principalEmail = "principal@example.com"; // Principal's email

    if (empty($personalEmail) || empty($officialEmail)) {
        echo "Error: Teacher emails not found for the selected class.";
        exit;
    }

    $to = "$personalEmail, $officialEmail"; // Send to both teacher emails
    $subject = "Year-End Feedback - $class";
    $message = "Anonymous feedback received from a student in $class:\n\n" . $feedback;
    $headers = "From: anonymous@example.com\r\n"; 
    $headers .= "Bcc: $principalEmail\r\n"; // BCC to Principal
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Send email
    if (mail($to, $subject, $message, $headers)) {
        echo "Feedback submitted successfully!";
    } else {
        echo "Error sending feedback.";
    }

    $conn->close();
}
?>
