<?php
session_start();
include 'db_connect.php';


$student_id = $_SESSION['student_id'];
$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);

    // Fetch the assigned teacher for the student's class
    $teacher_sql = "SELECT t.index_no FROM teachers t
                    INNER JOIN students s ON t.class_assigned = s.class
                    WHERE s.index_no = ?";
    $stmt = $conn->prepare($teacher_sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $stmt->bind_result($teacher_id);
    $stmt->fetch();
    $stmt->close();

    if (!empty($teacher_id)) {
        // Insert feedback into the database
        $insert_sql = "INSERT INTO feedbacks (student_id, teacher_id, message) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("iis", $student_id, $teacher_id, $message);

        if ($stmt->execute()) {
            $success_msg = "Feedback submitted successfully!";
        } else {
            $error_msg = "Error submitting feedback!";
        }
    } else {
        $error_msg = "No assigned teacher found for your class!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Feedback</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <h2>Submit Anonymous Feedback</h2>

    <?php if (isset($success_msg)): ?>
        <p style="color: green;"><?php echo $success_msg; ?></p>
    <?php elseif (isset($error_msg)): ?>
        <p style="color: red;"><?php echo $error_msg; ?></p>
    <?php endif; ?>

    <form method="post">
        <textarea name="message" placeholder="Write your feedback here..." required></textarea><br>
        <button type="submit">Submit Feedback</button>
    </form>
</body>
</html>
