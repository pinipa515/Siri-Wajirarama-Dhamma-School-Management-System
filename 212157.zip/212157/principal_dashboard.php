<?php
// principal_dashboard.php

// Start the session
session_start();

// Check if the user is logged in and is a Principal
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header("Location: index.html");
    exit();
}

// Fetch user details from the database (optional)
$host = 'localhost';
$dbname = 'project';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
$stmt->execute(['username' => $_SESSION['username']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user['position'] !== 'Principal') {
    // Redirect to the login page if not a Principal
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principal Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="protected-container">
        <h2>Welcome, Principal <?php echo htmlspecialchars($user['username']); ?>!</h2>
        <p>This is the Principal's dashboard. Only authorized users can view this content.</p>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>