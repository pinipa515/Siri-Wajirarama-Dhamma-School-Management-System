<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch distinct grades for filtering
$gradesQuery = "SELECT DISTINCT class FROM attendance ORDER BY class ASC";
$gradesResult = $conn->query($gradesQuery);

// Get selected date from dropdown
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d'); // Default: Today’s date

// Fetch attendance records based on the selected date
$sql = "SELECT * FROM attendance WHERE date = '$selectedDate' ORDER BY class ASC, student_name ASC";
$result = $conn->query($sql);

// Grouping records by class
$attendanceData = [];
while ($row = $result->fetch_assoc()) {
    $grade = $row['class'];
    $attendanceData[$grade][] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance - Siri Vajirarama Dhamma School</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <header>
        <h1>Daily Attendance Records</h1>
    </header>

    <main>
        <section>
            <h2>Select Date</h2>
            <form method="GET" action="">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" value="<?= $selectedDate ?>" required>
                <button type="submit">View</button>
            </form>
        </section>

        <section>
            <h2>Attendance List (<?= $selectedDate ?>)</h2>

            <?php if (!empty($attendanceData)): ?>
                <?php foreach ($attendanceData as $grade => $students): ?>
                    <h3>Grade <?= $grade ?></h3>
                    <table>
                        <tr>
                            <th>Student Index</th>
                            <th>Student Name</th>
                            <th>Status</th>
                        </tr>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?= $student['index_no'] ?></td>
                                <td><?= $student['student_name'] ?></td>
                                <td><?= ucfirst($student['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No attendance records found for this date.</p>
            <?php endif; ?>
        </section>
    </main>

    <!-- Back Button -->
    <div class="back-button-container">
        <a href="tea_dashboard.html" class="back-button">Back</a>
    </div>

    <footer>
        <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
