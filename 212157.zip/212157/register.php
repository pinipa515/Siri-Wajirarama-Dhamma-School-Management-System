<?php
include 'db_connect.php'; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Determine role (teacher or student) based on the submitted data
    $role = isset($_POST['teacher_name']) ? 'teacher' : 'student';

    // Initialize variables based on the role
    if ($role == 'teacher') {
        $name = $_POST['teacher_name'];
        $index = $_POST['teacher_index'];
        $work_start_date = $_POST['work_start_date'];
        $subjects = $_POST['subjects'];
        $position = $_POST['position'] ?? ''; // Ensure this matches the form field name
        $class = $_POST['class'];
        $phone = $_POST['teacher_phone'];
        $email = $_POST['teacher_email'];
        $password = $_POST['teacher_password'];
        $confirm_password = $_POST['teacher_confirm_password'];
    } else {
        $name = $_POST['student_name'];
        $index = $_POST['student_index'];
        $class = $_POST['student_class'];
        $phone = $_POST['student_phone'];
        $email = $_POST['student_email'];
        $password = $_POST['student_password'];
        $confirm_password = $_POST['student_confirm_password'];
    }

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match!'); window.history.back();</script>";
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Prepare SQL statement based on the role (teacher or student)
    if ($role == 'teacher') {
        $sql = "INSERT INTO teachers (name, index_no, work_start_date, subjects, position, class_assigned, phone, email, password) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    } else {
        $sql = "INSERT INTO students (name, index_no, class, phone, email, password) 
                VALUES (?, ?, ?, ?, ?, ?)";
    }

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    if ($role == 'teacher') {
        $stmt->bind_param("sssssssss", $name, $index, $work_start_date, $subjects, $position, $class, $phone, $email, $hashed_password);
    } else {
        $stmt->bind_param("ssssss", $name, $index, $class, $phone, $email, $hashed_password);
    }

    // Execute and redirect based on role
    if ($stmt->execute()) {
        session_start();
        $_SESSION['index'] = $index;
        $_SESSION['role'] = $role;

        if ($role == 'teacher') {
            echo "<script>alert('Registration successful! Redirecting to teacher dashboard.'); window.location.href='tea_dashboard.html';</script>";
        } else {
            echo "<script>alert('Registration successful! Redirecting to student dashboard.'); window.location.href='stu_dashboard.html';</script>";
        }
    } else {
        echo "<script>alert('Error: " . $stmt->error . "'); window.history.back();</script>";
    }

    // Close connections
    $stmt->close();
    $conn->close();
}    
?>
