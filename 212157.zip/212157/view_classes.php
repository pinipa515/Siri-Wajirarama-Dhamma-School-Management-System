<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

// Connect to database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch class and assigned teachers
$sql = "SELECT class_assigned, name FROM teachers ORDER BY class_assigned ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class & Assigned Teachers</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <header>
    <h1>Classes & Assigned Teachers</h1>
</header>
    <table>
        <tr>
            <th>Class</th>
            <th>Assigned Teacher</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['class_assigned']}</td><td>{$row['name']}</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No records found</td></tr>";
        }
        ?>
    </table>
    <div class="back-button-container">
        <a href="javascript:history.back()" class="back-button">Back</a>
    </div>


    <footer>
        <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
