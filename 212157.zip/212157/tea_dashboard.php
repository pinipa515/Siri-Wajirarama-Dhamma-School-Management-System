<?php 
session_start();

// Check if user is logged in and is a teacher or admin
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] != 'teacher' && $_SESSION['user_role'] != 'admin')) {
    header("Location: LOGIN1.html"); // Redirect to login page if unauthorized
    exit();
}
?>

