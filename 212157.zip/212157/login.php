<?php
session_start();
$conn = new mysqli("localhost", "root", "", "project");

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username']; // FIXED: Match with login form
    $password = $_POST['password'];

    // Identify user type based on index format
    if (strpos($username, 'T') === 0) {
        $role = 'teacher';
        $sql = "SELECT * FROM teachers WHERE index_no=?";
    } elseif (strpos($username, 'S') === 0) {
        $role = 'student';
        $sql = "SELECT * FROM students WHERE index_no=?";
    } else {
        echo "<script>alert('Invalid user index!'); window.location.href='LOGIN1.html';</script>";
        exit();
    }

    // Prepare and execute SQL query
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // FIXED: Proper password verification
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_role'] = $role;
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['loggedin'] = true;

            if ($role == 'teacher') {
                header("Location: dashboard.html");
            } else {
                header("Location: stu_dashboard.html");
            }
            exit();
        } else {
            echo "<script>alert('Invalid Password!'); window.location.href='LOGIN1.html';</script>";
        }
    } else {
        echo "<script>alert('User not found! Please register.'); window.location.href='authForms.html';</script>";
    }
    var_dump($row);
    exit();

    $stmt->close();
}

$conn->close();
