<?php
include 'db_connect.php'; // Database connection

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $index_number = $_POST['index_number'];
    $position = $_POST['position'];
    $assigned_class = $_POST['assigned_class'];
    $subject = $_POST['subject'];
    $phone = $_POST['phone'];  // New phone number field
    $email = $_POST['email'];  // New email field

    // Image upload handling
    $target_dir = "uploads/";
    $image_path = basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $image_path;
    move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);

    // Insert data into the database
    $sql = "INSERT INTO display_teachers (name, index_number, position, assigned_class, subject, phone, email, image_path)
            VALUES ('$name', '$index_number', '$position', '$assigned_class', '$subject', '$phone', '$email', '$target_file')";

    if (mysqli_query($conn, $sql)) {
        echo "Teacher added successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
