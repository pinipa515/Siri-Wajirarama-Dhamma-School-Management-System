<?php
include 'db_connect.php'; // Database connection

// Check if the search form is submitted
$search_name = '';
if (isset($_POST['search'])) {
    $search_name = mysqli_real_escape_string($conn, $_POST['search_name']);
}

// Modify the SQL query to include a search condition
$sql = "SELECT * FROM display_teachers WHERE name LIKE '%$search_name%'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Teachers</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .button-container {
            text-align: right; /* Aligns buttons to the right */
            margin-bottom: 10px;
        }
        .button-container button {
            margin-left: 10px; /* Adds spacing between buttons */
            padding: 10px 15px; /* Adjusts button size */
            cursor: pointer; /* Pointer on hover */
        }
    </style>
</head>
<body>
    <h1>Teacher Details</h1>

    <!-- Search form -->
    <form method="POST" action="">
        <input type="text" name="search_name" placeholder="Enter teacher's name" value="<?php echo htmlspecialchars($search_name); ?>" />
        <button type="submit" name="search">Search</button>
    </form>
  <!-- Back and Add Teacher Buttons -->
  <div class="button-container">
    <button onclick="window.location.href='add_teacher.html';">Add Teacher</button>
    <a href="javascript:history.back()" class="back-button">Back</a>
</div>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Index Number</th>
                <th>Position</th>
                <th>Assigned Class</th>
                <th>Subject</th>
                <th>Phone Number</th>
                <th>Email Address</th>
                <th>Image</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                // Display each row of data from the database
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['index_number']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['position']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['assigned_class']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['phone']) . "</td>"; // Display phone number
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>"; // Display email address
                    echo "<td><img src='" . $row['image_path'] . "' alt='Teacher Image' width='100' height='100'></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No teachers found</td></tr>";
            }
            ?>
        </tbody>
    </table>



</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>