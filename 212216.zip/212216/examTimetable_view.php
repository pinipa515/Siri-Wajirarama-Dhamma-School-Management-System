<?php

// Database connection
$conn = new mysqli("localhost", "root", "", "project");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch exam timetable data sorted by grade and exam date
$sql = "SELECT * FROM exam_timetable ORDER BY grade ASC, exam_date ASC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Exam Timetable</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <h1>Exam Timetable</h1>
    
    <!-- Back Button before Footer -->
    <div class="back-button-container">
        <a href="javascript:history.back()" class="back-button">Back</a>
    </div>
    
    <?php
    // Display timetable data in a table format
    if ($result->num_rows > 0) {
        echo "<table border='1' cellpadding='10'>";
        echo "<tr><th>Grade</th><th>Subject</th><th>Exam Type</th><th>Exam Date</th><th>Time</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['grade'] . "</td>";
            echo "<td>" . $row['subject'] . "</td>";
            echo "<td>" . $row['exam_type'] . "</td>";
            echo "<td>" . $row['exam_date'] . "</td>";
            echo "<td>" . $row['start_time'] . " - " . $row['end_time'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No exam timetable available.";
    }
    
    $conn->close();
    ?>
    <footer>
        <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
    </footer> 

</body>
</html>

    