<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Corrected Database connection
    $conn = new mysqli("localhost", "root", "", "project");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $grade = $_POST['grade'];
    $exam_type = $_POST['exam_type'];
    $exam_date = $_POST['exam_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $subject = $_POST['subject'];
    $uploaded_by = 'TeacherName'; // Use session or teacher ID for this

    $sql = "INSERT INTO exam_timetable (grade, exam_type, exam_date, start_time, end_time, subject, uploaded_by)
            VALUES ('$grade', '$exam_type', '$exam_date', '$start_time', '$end_time', '$subject', '$uploaded_by')";

    if ($conn->query($sql) === TRUE) {
        
        echo "<script>alert('New timetable  recorded successfully.'); window.location.href='examTimetable.html';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
