<?php 
include 'db_connect.php'; // Ensure this file correctly connects to the database

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if a search term has been submitted
$search_term = "";
if (isset($_POST['search'])) {
    $search_term = $_POST['search'];
}

// Fetch the uploaded files from the database, optionally filtered by search term
$sql = "SELECT * FROM files WHERE filename LIKE '%$search_term%'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Uploaded Files</title>
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href=style3.css>
</head>
<body>
<header> <h1>Uploaded Files</h1> </header>
	<div class="container mt-5">
        <!-- Search Form -->
        <form method="POST" action="">
            <div class="input-group mb-4">
                
                <input type="text" class="form-control" name="search" value="<?php echo htmlspecialchars($search_term); ?>" placeholder="Search by file name">
                <button class="btn btn-outline-secondary" type="submit">Search</button>
            </div>
        </form>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>File Type</th>
                    <th>Download</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Display the uploaded files and download links
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $file_path = "uploads/" . $row['filename'];
                        ?>
                        <tr>
                            <td><?php echo $row['filename']; ?></td>
                            <td><?php echo $row['filetype']; ?></td>
                            <td><a href="<?php echo $file_path; ?>" class="btn btn-primary" download>Download</a></td>
                        </tr>
                        <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="4">No files found matching the search term.</td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
    <div class="back-button-container">
        <a href="javascript:history.back()" class="back-button">Back</a>
    </div>
    
<footer>
    <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
</footer>
</body>
</html>

<?php
$conn->close();
?>
