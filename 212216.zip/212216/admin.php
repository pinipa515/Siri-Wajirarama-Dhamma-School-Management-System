<?php
// login.php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$index_no = $_POST['index_no'];
$password_input = $_POST['password'];

// SQL query to check if the user exists and is a Principal
$sql = "SELECT * FROM teachers WHERE index_no = ? AND position = 'Principal'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $index_no);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch user data
    $row = $result->fetch_assoc();
    
    // Check if the entered password matches the hashed password in the database
    if (password_verify($password_input, $row['password'])) {
        // User is authenticated, redirect to the principal dashboard
        header("Location: principal_dashboard.html");
        exit();
    } else {
        // Invalid password
        echo "Invalid login credentials.";
    }
} else {
    // User not found or incorrect position
    echo "No user found with the specified index number or you do not have the required position.";
}

$conn->close();
?>
