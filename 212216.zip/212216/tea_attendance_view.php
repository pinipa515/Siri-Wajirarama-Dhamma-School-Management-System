<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get selected date from dropdown
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d'); // Default: Today’s date

// Fetch attendance records based on the selected date
$sql = "SELECT * FROM teacher_attendance WHERE date = '$selectedDate' ORDER BY T_name ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Teacher Attendance - Siri Vajirarama Dhamma School</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
    <header>
        <h1>Teacher Attendance Records</h1>
    </header>

    <main>
        <section>
            <h2>Select Date</h2>
            <form method="GET" action="">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" value="<?= $selectedDate ?>" required>
                <button type="submit">View</button>
            </form>
        </section>

        <section>
            <h2>Attendance List (<?= $selectedDate ?>)</h2>

            <?php if ($result->num_rows > 0): ?>
                <table>
                    <tr>
                        <th>Teacher Index</th>
                        <th>Teacher Name</th>
                        <th>Status</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['index_no'] ?></td>
                            <td><?= $row['T_name'] ?></td>
                            <td><?= ucfirst($row['status']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <p>No attendance records found for this date.</p>
            <?php endif; ?>
        </section>
    </main>

    <!-- Back Button -->
    <div class="back-button-container">
        <a href="javascript:history.back()" class="back-button">Back</a>
    </div>


    <footer>
        <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
