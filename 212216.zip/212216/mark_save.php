<?php
// Database connection
$servername = "localhost";  // Change if needed
$username = "root";         // Your MySQL username
$password = "";             // Your MySQL password
$dbname = "project"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $student_name = $_POST['student_name'];
    $student_index = $_POST['student_index'];
    $grade = $_POST['grade'];
    $exam_type = $_POST['exam_type'];
    $subject = $_POST['subject'];
    $marks = $_POST['marks'];

    // Prepare an SQL query to insert the data into the database
    $sql = "INSERT INTO student_marks (student_name, student_index, grade, exam_type, subject, marks)
            VALUES ('$student_name', '$student_index', '$grade', '$exam_type', '$subject', '$marks')";

    // Execute the query and check if the insertion was successful
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Attendance recorded successfully.'); window.location.href='marks_enter.html';</script>";
    } else {
        echo "<script>alert('Error: Unable to record attendance.'); window.location.href='marks_enter.html';</script>";
    }

    // Close the connection
    $conn->close();
}
?>