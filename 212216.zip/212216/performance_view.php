<?php 
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$performance = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $index_no = $_POST['index_no'];
    $year = $_POST['year'];

    // Fetch student performance
    $sql = "SELECT * FROM student_performance WHERE index_no='$index_no' AND year=$year";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $performance = $result->fetch_assoc();
    } else {
        $error = "No record found for the given Index Number and Year.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student Performance</title>
    <link rel="stylesheet" href="style4.css">
    <script>
        function clearForm() {
            document.getElementById("index_no").value = "";
            document.getElementById("year").value = "";
        }
    </script>
</head>
<body>
    <header>
        <h1>Our staff</h1>
    </header>

    <h2>Search Student Performance</h2>
    <form action="" method="POST">
        <label for="index_no">Student Index:</label>
        <input type="text" name="index_no" id="index_no" required><br>

        <label for="year">Year:</label>
        <input type="number" name="year" id="year" required><br>

        <input type="submit" value="Search">
        <input type="button" value="Clear" onclick="clearForm()">
    </form>
        <br>
        <br>
        <h2>Students Performance </h2>
    <?php if (isset($performance)) { ?>
        
        <h3>Performance Details for <?php echo htmlspecialchars($performance['name']); ?></h3>
        <p><strong>Index No:</strong> <?php echo htmlspecialchars($performance['index_no']); ?></p>
        <p><strong>Competition Wins:</strong> <?php echo htmlspecialchars($performance['competition_wins']); ?></p>
        <p><strong>Positions Held:</strong> <?php echo htmlspecialchars($performance['s_positions']); ?></p>
        <p><strong>Year:</strong> <?php echo htmlspecialchars($performance['year']); ?></p>
    <?php } elseif (isset($error)) { ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php } ?>

    <div class="back-button-container">
        <a href="javascript:history.back()" class="back-button">Back</a>
    </div>
    
    <footer>
        <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
    </footer>

</body>
</html>