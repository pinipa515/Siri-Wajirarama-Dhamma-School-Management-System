<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $index_no = $_POST['index_no'];
    $competition_wins = $_POST['competition_wins'];
    $s_positions = $_POST['s_positions'];
    $year = $_POST['year'];

    // Check if the performance for this student already exists for the given year
    $sql = "SELECT * FROM student_performance WHERE index_no='$index_no' AND year=$year";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Update the record if it already exists
        $update_sql = "UPDATE student_performance SET 
                        name='$name', 
                        competition_wins='$competition_wins', 
                        s_positions='$s_positions' 
                        WHERE index_no='$index_no' AND year=$year";
        if ($conn->query($update_sql) === TRUE) {
            echo "Record updated successfully!";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    } else {
        // Insert a new record
        $insert_sql = "INSERT INTO student_performance (name, index_no, competition_wins, s_positions, year) 
                        VALUES ('$name', '$index_no', '$competition_wins', '$s_positions', $year)";
        if ($conn->query($insert_sql) === TRUE) {
            echo "New record created successfully!";
        } else {
            echo "Error: " . $insert_sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
