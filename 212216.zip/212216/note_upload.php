<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $target_dir = "uploads/";
        $filename = basename($_FILES["file"]["name"]);
        $target_file = $target_dir . $filename;
        $filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $filesize = $_FILES["file"]["size"];
        $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf");

        if (!in_array($filetype, $allowed_types)) {
            echo "Invalid file type.";
        } elseif (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            $sql = "INSERT INTO files (filename, filesize, filetype) VALUES ('$filename', $filesize, '$filetype')";
            if ($conn->query($sql) === TRUE) {
                echo "File uploaded successfully.";
            } else {
                echo "Database error: " . $conn->error;
            }
        } else {
            echo "File upload error.";
        }
    } else {
        echo "No file uploaded.";
    }
}
?>