<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_index = "";

// If search is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_index = $_POST["student_index"];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Exam Marks</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>

    <header>
        <h1>Search Student Exam Marks</h1>
    </header>
    
    <form method="POST">
        <input type="text" name="student_index" placeholder="Enter Student Index" required value="<?php echo $student_index; ?>">
        <button type="submit">Search</button>
    </form>

    <?php
    function displayMarksTable($conn, $term, $student_index) {
        // Query to get marks based on term and student index
        $sql = "SELECT * FROM student_marks WHERE exam_type='$term'";
        
        if (!empty($student_index)) {
            $sql .= " AND student_index='$student_index'";
        }

        $result = $conn->query($sql);

        echo "<h1>$term Marks</h1>";
        echo "<table border='1' style='width: 80%; margin: auto; text-align: center;'>";
        echo "<tr><th>ID</th><th>Student Name</th><th>Student Index</th><th>Grade</th><th>Subject</th><th>Marks</th></tr>";

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$row["id"]."</td>
                        <td>".$row["student_name"]."</td>
                        <td>".$row["student_index"]."</td>
                        <td>".$row["grade"]."</td>
                        <td>".$row["subject"]."</td>
                        <td>".$row["marks"]."</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No marks found for $term.</td></tr>";
        }

        echo "</table><br>";
    }

    // Display separate tables for 1st term and 2nd term
    displayMarksTable($conn, "1st term", $student_index);
    displayMarksTable($conn, "2nd term", $student_index);
    

    $conn->close();
    ?>
    
    <div class="back-button-container">
        <a href="javascript:history.back()" class="back-button">Back</a>
    </div>

    <footer>
        <p>&copy; 2025 Siri Vajirarama Dhamma School | Designed by Sandali and Dewindi</p>
    </footer>

</body>
</html>
