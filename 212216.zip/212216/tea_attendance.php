<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $index_no = mysqli_real_escape_string($conn, $_POST['index_no']);
    $T_name = mysqli_real_escape_string($conn, $_POST['T_name']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Insert attendance record into the database
    $sql = "INSERT INTO teacher_attendance (date, index_no, T_name, status) 
            VALUES ('$date', '$index_no', '$T_name', '$status')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Attendance recorded successfully.'); window.location.href='tea_attendance.html';</script>";
    } else {
        echo "<script>alert('Error: Unable to record attendance.'); window.location.href='tea_attendance.html';</script>";
    }
}

$conn->close();
?>
