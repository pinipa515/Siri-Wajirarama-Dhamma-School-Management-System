<?php
session_start();
// Temporarily disable login requirement for testing
// if (!isset($_SESSION['user_id'])) {
//     header("Location: login.html");
//     exit();
// }

// Simulate a user session for testing
$_SESSION['user_id'] = 1;
$_SESSION['role'] = 'admin'; // Change to 'teacher' or 'student' as needed
$_SESSION['name'] = 'Test User';
?>



